
drop database if exists hoteladmin_db;
create database hoteladmin_db;
use  hoteladmin_db;
create table hotel(
   hotel_Id int auto_increment ,
  hotel_Name varchar(50)not null,
   hotel_Email varchar(50) not null,
   hotel_Address varchar(100)not null,
   hotel_City varchar(30) not null,
   hotel_State varchar(20) not null,
   hotel_Country varchar(20) not null,
   hotel_Telephone varchar(15) not null,
   hotel_Pincode int(6) not null,
   no_Of_Rooms int(200) not null,
   no_Of_Tables int(150) not null,
   no_Of_Partyhalls int(100) not null,
   image blob,
   status varchar(20) ,
   constraint ps_hotelId_pk primary key (hotel_Id)
);
insert into `hotel` values(1,'Leela Palace','reservations@theleela.com','Adyar sea face,Sathyadev Avenue,MRC nagar','chennai','Tamil Nadu','India','04433661234','600028',136,80,4,'null','Requested');
insert into `hotel` values(2,'Radisson Blu','reservations@radissongrt.com','165,Avinashi Rd,near Nava India Signal,Peelamedu','Coimbatore','Tamil Nadu','India','0422 222 6000','641004',52,14,0,'null','Requested');
insert into `hotel` values(3,'Vivanta Coimbatore','bookvivanta.coimbatore@tajhotels.com','105,Race course road,Gopalapuram','Coimbatore','Tamil Nadu','India','0422 668 1000','641018',80,30,4,'null','Requested');
insert into `hotel` values(4,'The Vedic village	','reservations@thevedicvillage.com ','Shikharpur,P.O,Newtown','Kolkata','West Bengal','India','098300 25900','700135',100,30,4,'null','Requested');
insert into `hotel` values(5,'ITC Grand chola','reservations@itchotels.in','63,Mount Road,Guindy','Chennai','Tamil Nadu','India','914422200200','6000032',128,30,4,'null','Requested');
insert into `hotel` values(6,'The Park','resv.che@theparkhotels.com','601,Anna salai,Nungambakkam,NearUS embassy','Chennai','Tamil Nadu','India','04442144100','6000006',149,80,3,'null','Requested');
select * from hotel;