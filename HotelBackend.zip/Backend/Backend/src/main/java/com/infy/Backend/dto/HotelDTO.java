package com.infy.Backend.dto;

	import java.util.Arrays;

	public class HotelDTO {    
		private Integer hotelId;
	    private String hotelName;
	    private String hotelEmail;
	    private String hotelAddress;
	    private String hotelCity;
	    private String hotelState;
	    private String hotelCountry;
	    private String hotelTelephone;
	    private Integer hotelPincode;
	    private Integer noOfRooms;
	    private Integer noOfTables;
	    private Integer noOfPartyhalls;
	    private String image;
	    private String status;
	    
		public Integer getHotelId() {
			return hotelId;
		}
		public void setHotelId(Integer hotelId) {
			this.hotelId = hotelId;
		}
		public String getHotelName() {
			return hotelName;
		}
		public void setHotelName(String hotelName) {
			this.hotelName = hotelName;
		}
		public String getHotelEmail() {
			return hotelEmail;
		}
		public void setHotelEmail(String hotelEmail) {
			this.hotelEmail = hotelEmail;
		}
		public String getHotelAddress() {
			return hotelAddress;
		}
		public void setHotelAddress(String hotelAddress) {
			this.hotelAddress = hotelAddress;
		}
		public String getHotelCity() {
			return hotelCity;
		}
		public void setHotelCity(String hotelCity) {
			this.hotelCity = hotelCity;
		}
		public String getHotelState() {
			return hotelState;
		}
		public void setHotelState(String hotelState) {
			this.hotelState = hotelState;
		}
		public String getHotelCountry() {
			return hotelCountry;
		}
		public void setHotelCountry(String hotelCountry) {
			this.hotelCountry = hotelCountry;
		}
		public String getHotelTelephone() {
			return hotelTelephone;
		}
		public void setHotelTelephone(String hotelTelephone) {
			this.hotelTelephone = hotelTelephone;
		}
		public Integer getHotelPincode() {
			return hotelPincode;
		}
		public void setHotelPincode(Integer hotelPincode) {
			this.hotelPincode = hotelPincode;
		}
		public Integer getNoOfRooms() {
			return noOfRooms;
		}
		public void setNoOfRooms(Integer noOfRooms) {
			this.noOfRooms = noOfRooms;
		}
		public Integer getNoOfTables() {
			return noOfTables;
		}
		public void setNoOfTables(Integer noOfTables) {
			this.noOfTables = noOfTables;
		}
		public Integer getNoOfPartyhalls() {
			return noOfPartyhalls;
		}
		public void setNoOfPartyhalls(Integer noOfPartyhalls) {
			this.noOfPartyhalls = noOfPartyhalls;
		}
		
		public String getImage() {
			return image;
		}
		public void setImage(String image) {
			this.image = image;
		}
		public String getStatus() {
			return status;
		}
		public void setStatus(String status) {
			this.status = status;
		}
		@Override
		public String toString() {
			return "HotelDTO [hotelId=" + hotelId + ", hotelName=" + hotelName + ", hotelEmail=" + hotelEmail
					+ ", hotelAddress=" + hotelAddress + ", hotelCity=" + hotelCity + ", hotelState=" + hotelState
					+ ", hotelCountry=" + hotelCountry + ", hotelTelephone=" + hotelTelephone + ", hotelPincode="
					+ hotelPincode + ", noOfRooms=" + noOfRooms + ", noOfTables=" + noOfTables + ", noOfPartyhalls="
					+ noOfPartyhalls + ", image=" + image + ", status=" + status + "]";
		}
		
	    
			
	}
