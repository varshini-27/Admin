package com.infy.Backend.Service;

import java.util.List;

import com.infy.Backend.Exception.HotelException;
import com.infy.Backend.dto.HotelDTO;
public interface HotelService {
	public Integer addHotel(HotelDTO hoteldto) throws HotelException;
	public List<HotelDTO> getAllHotels() throws HotelException;
	public void updateHotel(Integer hotelId, String status)throws HotelException;
	public void deleteHotel(Integer hotelId) throws HotelException;
	
	
}
