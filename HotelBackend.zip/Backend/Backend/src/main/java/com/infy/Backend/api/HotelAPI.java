package com.infy.Backend.api;

	import org.springframework.core.env.Environment;

	import java.util.List;

	import org.springframework.beans.factory.annotation.Autowired;

	import org.springframework.http.HttpStatus;
	import org.springframework.http.ResponseEntity;
	import org.springframework.validation.annotation.Validated;
	import org.springframework.web.bind.annotation.CrossOrigin;
	import org.springframework.web.bind.annotation.DeleteMapping;
	import org.springframework.web.bind.annotation.GetMapping;
	import org.springframework.web.bind.annotation.PathVariable;
	import org.springframework.web.bind.annotation.PostMapping;
	import org.springframework.web.bind.annotation.PutMapping;
	import org.springframework.web.bind.annotation.RequestBody;
	import org.springframework.web.bind.annotation.RequestMapping;
	import org.springframework.web.bind.annotation.RestController;

import com.infy.Backend.Exception.HotelException;
import com.infy.Backend.Service.HotelService;
import com.infy.Backend.dto.HotelDTO;


	@RestController
	@RequestMapping(value = "/hotelDetails")
	@CrossOrigin(origins="http://localhost:3000")
	@Validated
	public class HotelAPI {

			@Autowired
			private Environment environment;
			@Autowired
			private HotelService hotelService;
			
			@GetMapping(value = "/hotels")
			public ResponseEntity<List<HotelDTO>> getAllHotels() throws HotelException {
				List<HotelDTO> hotelList = hotelService.getAllHotels();
				return new ResponseEntity<>(hotelList, HttpStatus.OK);
			}
			@PostMapping(value = "/hotel")
			public ResponseEntity<String> addHotel( @RequestBody HotelDTO hotel) throws HotelException {
				Integer hotelId = hotelService.addHotel(hotel);
				String successMessage = environment.getProperty("API.INSERT_SUCCESS") + hotelId;
				return new ResponseEntity<>(successMessage, HttpStatus.CREATED);
			}
			
			@DeleteMapping(value = "/hotel/{id}")
			public ResponseEntity<String> deleteHotel(@PathVariable Integer id) throws HotelException {
				hotelService.deleteHotel(id);
				String successMessage = environment.getProperty("API.DELETE_SUCCESS");
				return new ResponseEntity<>(successMessage, HttpStatus.OK);
			}
			@PutMapping(value = "/hotels/{id}")
			public ResponseEntity<String> updateHotel(@PathVariable Integer id, @RequestBody HotelDTO hotel)
					throws HotelException {
				hotelService.updateHotel(id, hotel.getStatus());
				String successMessage = environment.getProperty("API.UPDATE_SUCCESS");
				return new ResponseEntity<>(successMessage, HttpStatus.OK);
			}
	}