package com.infy.Backend.Repository;
import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.infy.Backend.entity.hotel;


public interface HotelRepository extends CrudRepository<hotel, Integer> {
	
}