package com.infy.Backend.entity;

	import java.util.Arrays;

	import javax.persistence.Basic;
	import javax.persistence.Entity;
	import javax.persistence.FetchType;
	import javax.persistence.GeneratedValue;
	import javax.persistence.GenerationType;
	import javax.persistence.Id;
	import javax.persistence.Lob;

	@Entity
	public class hotel {
		@Id
		@GeneratedValue(strategy = GenerationType.IDENTITY)
		private Integer hotelId;
	    private String hotelName;
	    private String hotelEmail;
	    private String hotelAddress;
	    private String hotelCity;
	    private String hotelState;
	    private String hotelCountry;
	    private String hotelTelephone;
	    private Integer hotelPincode;
	    private Integer noOfRooms;
	    private Integer noOfTables;
	    private Integer noOfPartyhalls;
	   @Lob
	    @Basic(fetch=FetchType.LAZY)
	   private String image;
	    private String status;
		public hotel() {
			super();
			this.hotelId = hotelId;
			this.hotelName = hotelName;
			this.hotelEmail = hotelEmail;
			this.hotelAddress = hotelAddress;
			this.hotelCity = hotelCity;
			this.hotelState = hotelState;
			this.hotelCountry = hotelCountry;
			this.hotelTelephone = hotelTelephone;
			this.hotelPincode = hotelPincode;
			this.noOfRooms = noOfRooms;
			this.noOfTables = noOfTables;
			this.noOfPartyhalls = noOfPartyhalls;
			this.image = image;
			this.status = status;
		}
	public Integer getHotelId() {
			return hotelId;
		}
		public void setHotelId(Integer hotelId) {
			this.hotelId = hotelId;
		}
		public String getHotelName() {
			return hotelName;
		}
		public void setHotelName(String hotelName) {
			this.hotelName = hotelName;
		}
		public String getHotelEmail() {
			return hotelEmail;
		}
		public void setHotelEmail(String hotelEmail) {
			this.hotelEmail = hotelEmail;
		}
		public String getHotelAddress() {
			return hotelAddress;
		}
		public void setHotelAddress(String hotelAddress) {
			this.hotelAddress = hotelAddress;
		}
		public String getHotelCity() {
			return hotelCity;
		}
		public void setHotelCity(String hotelCity) {
			this.hotelCity = hotelCity;
		}
		public String getHotelState() {
			return hotelState;
		}
		public void setHotelState(String hotelState) {
			this.hotelState = hotelState;
		}
		public String getHotelCountry() {
			return hotelCountry;
		}
		public void setHotelCountry(String hotelCountry) {
			this.hotelCountry = hotelCountry;
		}
		public String getHotelTelephone() {
			return hotelTelephone;
		}
		public void setHotelTelephone(String hotelTelephone) {
			this.hotelTelephone = hotelTelephone;
		}
		public Integer getHotelPincode() {
			return hotelPincode;
		}
		public void setHotelPincode(Integer hotelPincode) {
			this.hotelPincode = hotelPincode;
		}
		public Integer getNoOfRooms() {
			return noOfRooms;
		}
		public void setNoOfRooms(Integer noOfRooms) {
			this.noOfRooms = noOfRooms;
		}
		public Integer getNoOfTables() {
			return noOfTables;
		}
		public void setNoOfTables(Integer noOfTables) {
			this.noOfTables = noOfTables;
		}
		public Integer getNoOfPartyhalls() {
			return noOfPartyhalls;
		}
		public void setNoOfPartyhalls(Integer noOfPartyhalls) {
			this.noOfPartyhalls = noOfPartyhalls;
		}
		public String getImage() {
			return image;
		}
		public void setImage(String image) {
			this.image = image;
		}
		public String getStatus() {
			return status;
		}
		public void setStatus(String status) {
			this.status = status;
		}
		@Override
		public String toString() {
			return "hotel [hotelId=" + hotelId + ", hotelName=" + hotelName + ", hotelEmail=" + hotelEmail
					+ ", hotelAddress=" + hotelAddress + ", hotelCity=" + hotelCity + ", hotelState=" + hotelState
					+ ", hotelCountry=" + hotelCountry + ", hotelTelephone=" + hotelTelephone + ", hotelPincode="
					+ hotelPincode + ", noOfRooms=" + noOfRooms + ", noOfTables=" + noOfTables + ", noOfPartyhalls="
					+ noOfPartyhalls + ", image=" + image + ", status=" + status + "]";
		}
		@Override
		public int hashCode() {
			final int prime = 31;
			int result = 1;
			result = prime * result + ((hotelId == null) ? 0 : hotelId.hashCode());
			return result;
		}
		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			hotel other = (hotel) obj;
			if (hotelId == null) {
				if (other.hotelId != null)
					return false;
			} else if (!hotelId.equals(other.hotelId))
				return false;
			return true;
		}
	    
		
}
