package com.infy.Backend.Service;
	import java.util.ArrayList;
	import java.util.List;
	import java.util.Optional;

	import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.stereotype.Service;
	import org.springframework.transaction.annotation.Transactional;

import com.infy.Backend.Exception.HotelException;
import com.infy.Backend.Repository.HotelRepository;
import com.infy.Backend.dto.HotelDTO;
import com.infy.Backend.entity.hotel;
	@Service(value = "hotelService")
	@Transactional
	public class HotelServiceImpl implements HotelService{
			@Autowired
			private HotelRepository hotelRepository;

			@Override
			public Integer addHotel(HotelDTO hoteldto) throws HotelException {
				 hotel hotel1= new hotel();
				 hotel1.setHotelId(hoteldto.getHotelId());
				 hotel1.setHotelName(hoteldto.getHotelName());
				 hotel1.setHotelEmail(hoteldto.getHotelEmail());
				 hotel1.setHotelAddress(hoteldto.getHotelAddress());
				 hotel1.setHotelCity(hoteldto.getHotelCity());
				 hotel1.setHotelState(hoteldto.getHotelState());
				 hotel1.setHotelCountry(hoteldto.getHotelCountry());
				 hotel1.setHotelPincode(hoteldto.getHotelPincode());
				 hotel1.setHotelTelephone(hoteldto.getHotelTelephone());
				 hotel1.setImage(hoteldto.getImage());
				 hotel1.setNoOfPartyhalls(hoteldto.getNoOfPartyhalls());
				 hotel1.setNoOfRooms(hoteldto.getNoOfRooms());
				 hotel1.setNoOfTables(hoteldto.getNoOfTables());
				 hotel1.setStatus(hoteldto.getStatus());
				hotel hotel2=hotelRepository.save(hotel1);
				return hotel2.getHotelId();
			}
			@Override
			public List<HotelDTO> getAllHotels() throws HotelException {
				Iterable<hotel> hotels = hotelRepository.findAll();
				List<HotelDTO> hoteldtos= new ArrayList<>();
				hotels.forEach(hoteldto -> {
					HotelDTO hotl= new HotelDTO();
					 hotl.setHotelId(hoteldto.getHotelId());
					 hotl.setHotelName(hoteldto.getHotelName());
					 hotl.setHotelEmail(hoteldto.getHotelEmail());
					 hotl.setHotelAddress(hoteldto.getHotelAddress());
					 hotl.setHotelCity(hoteldto.getHotelCity());
					 hotl.setHotelState(hoteldto.getHotelState());
					 hotl.setHotelCountry(hoteldto.getHotelCountry());
					 hotl.setHotelPincode(hoteldto.getHotelPincode());
					 hotl.setHotelTelephone(hoteldto.getHotelTelephone());
					 hotl.setImage(hoteldto.getImage());
					 hotl.setNoOfPartyhalls(hoteldto.getNoOfPartyhalls());
					 hotl.setNoOfRooms(hoteldto.getNoOfRooms());
					 hotl.setNoOfTables(hoteldto.getNoOfTables());
					hotl.setStatus(hoteldto.getStatus());
					hoteldtos.add(hotl);
				});
				if (hoteldtos.isEmpty())
					throw new HotelException("Service.HOTEL_NOT_FOUND");
				return hoteldtos;
			}
			@Override
			public void deleteHotel(Integer id) throws HotelException {
				Optional<hotel> hotels = hotelRepository.findById(id);
				hotels.orElseThrow(() -> new HotelException("Service.HOTEL_NOT_FOUND"));
				hotelRepository.deleteById(id);
			}
			@Override
			public void updateHotel(Integer id, String status) throws HotelException {
				Optional<hotel> hotl = hotelRepository.findById(id);
				hotel h = hotl.orElseThrow(() -> new HotelException("Service.HOTEL_NOT_FOUND"));
				h.setStatus(status);
			}
		
}
