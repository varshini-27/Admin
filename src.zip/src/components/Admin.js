import React, { Component } from 'react'
import axios  from 'axios';
import {Link} from 'react-router-dom';
import './Admin.css';
class Admin extends Component {
   
    constructor() {
        super();
        this.state = {
            buttonClicked: false,
                result: [],
                errorMessage: ""
              };
              this.getAllHotels=this.getAllHotels.bind(this);
              this.updateHotel=this.updateHotel.bind(this);
    }
    componentDidMount() {
        this.getAllHotels();
      }
      getAllHotels() {
        axios
          .get("http://localhost:8765/hotelDetails/hotels/")
          .then(response => {console.log(this.state.response)
            this.setState({
              
              result: response.data,
              errorMessage: ""
            });
           
          })
          .catch(error => {
            if (error.response) {
              this.setState({
                errorMessage: error.response.data.message,
                result: ""
              });
            } else {
              this.setState({ errorMessage: error.message, result: "" });
            }
          });
          
      }
    deleteHotel=(hotelid)=>{
            axios.delete("http://localhost:8765/hotelDetails/hotel/"+hotelid)
            .then(response=>{
               
                if(response.data!=null){
                    this.setState({
                        result:this.state.result.filter(hotel=>hotel.hotelId!==hotelid)
                    })
                }
            })
            
      alert('Hotel details are deleted successfully!')
    };
    updateHotel=(hotelid)=>{
        console.log(hotelid);
        const data={status: 'Accepted'};
        axios.put('http://localhost:8765/hotelDetails/hotels/'+hotelid,data)
        .then(response=>{
                 
          if(response.data!=null){
            this.setState({
              
              result:this.state.result.filter(hotel=>  hotel.hotelId!==hotelid)
               
            })
        }
      })
      .catch(error => {
        if (error.response) {
            console.log( error.response.data.message)
          this.setState({
          
          });
        } else {
          this.setState({ errorMessage: error.message, result: "" });
        }
      })
        alert('Hotel details are added to the database successfully!')
      }

render() {
    return ( <div>
        <div>
       
     <nav className="navbar navbar-expand-lg bg-secondary navbar-dark fixed-top" style={{'font-size':'22px'}} >
       <div className="navbar-header">
         <a className="nav-item active navbar-brand" href="/" style={{'font-size':'25px'}}>Hotel Management System</a>
       </div>
       <ul className="navbar-nav ml-auto ">
         
         
         <li className="nav-item mb-0 h3" >
           <Link className="nav-link " to="/logout" >Logout&nbsp;<i class="fa fa-sign-out" aria-hidden="true"></i></Link>
         
        </li>
       </ul>
     </nav> 
     </div>
     
     <div className="roww">
     
    <div className="card-title">
  <h1 className="text-center text-dark"><br/>DEALER REQUEST</h1></div>
{this.state.result
      ? this.state.result.filter(hotel=>hotel.status==="Requested").map(hotel =><div>
    <div className="card" style={{ "width":"52rem","height":"520px"}}>
    <img className="card-img-top" src={require("../assets/crowne.jfif")} height="450" alt="Card image cap" />
        <div className="card-body">
            <h2 className="card-title text-primary">{hotel.hotelName}</h2>
                <p className="card-text">
                  <span><b>Hotel Id: </b>{hotel.hotelId}</span><br/>
                  <span><b>Hotel Name: </b>{hotel.hotelName}</span><br/>
                  <span><b>Hotel EmailId: </b>{hotel.hotelEmail}</span><br/>
                  <span><b>Hotel Address: </b>{hotel.hotelAddress}</span><br/>
                  <span><b>Hotel City: </b>{hotel.hotelCity}</span><br/>
                  <span><b>Hotel State: </b>{hotel.hotelState}</span><br/>
                  <span><b>Hotel Country: </b>{hotel.hotelCountry}</span><br/>
                  <span><b>Hotel Telephone Number: </b>{hotel.hotelTelephone}</span><br/>
                  <span><b>Hotel Pincode: </b>{hotel.hotelPincode}</span><br/>
                  <span><b>Number of Rooms: </b>{hotel.noOfRooms}</span><br/>
                  <span><b>Number of Tables: </b>{hotel.noOfTables}</span><br/>
                  <span><b>Number of Party Halls: </b>{hotel.noOfPartyhalls}</span>
                </p>
                <h2 className="card-footer texxt-center">
               <center><button type="button" id="btn" className="btn btn-info btn-lg" onClick={()=>this.updateHotel(hotel.hotelId)}>Accept</button>&nbsp;&nbsp;
               <button className="btn btn-success btn-lg" id="btn" onClick={this.deleteHotel.bind(this,hotel.hotelId)}>Reject</button></center></h2>
      </div></div></div>) : null}
                 {this.state.errorMessage ? (
                    <h4 className="text-danger">{this.state.errorMessage}</h4>
                  ) : null}
          
 </div></div>
    );
  }
}
export default Admin;