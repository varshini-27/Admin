import React from 'react';
import './login.css';
import {withRouter} from 'react-router-dom';
class login extends React.Component {
    constructor() {
        super();
        this.state = {
            formValue: {
                adminName: "",
                adminPassword: ""
            },
            formErrorMessage: {
                adminName: "",
                adminPassword: ""
            },
            formValid: {
                adminName: false,
                adminPassword: false,
                buttonActive: false

            },
            successMessage: "",
            errorMessage: ""
        }
    }
  
    nextPath(path) {
        this.props.history.push(path);
      }
    handleChange = (event) => {
        var name = event.target.name
        var value = event.target.value
        var { formValue } = this.state

        this.setState({ formValue: { ...formValue, [name]: value } })
        this.validateField(name, value)
    }

    validateField = (fieldName, value) => {
        let formErrorMessage = this.state.formErrorMessage
        let formValid = this.state.formValid
        switch (fieldName) {
            case "adminName":
                if (value === "") {
                    formErrorMessage.adminName = "Field required"
                    formValid.adminName = false
                }
                else if (value!== "Admin") {
                    formErrorMessage.adminName = "Username is incorrect"
                    formValid.adminName = false
                }
                else if (value=== "Admin") {
                    formErrorMessage.adminName = ""
                    formValid.adminName = true
                }
                break;
            case "adminPassword":
                if (value === "") {
                    formErrorMessage.adminPassword = "Field required"
                    formValid.adminPassword= false
                }
                else if (value=== "Admin123"){
                    formErrorMessage.adminPassword = ""
                    formValid.adminPassword = true
                }
                else if (value!== "Admin123") {
                    formErrorMessage.adminPassword = "Password is incorrect"
                    formValid.adminPassword = false
                }
                break;
                default:break;
                 
        }
        formValid.buttonActive = formValid.adminName && formValid.adminPassword ;
        this.setState({ formErrorMessage: formErrorMessage, successMessage: "", errorMessage: "" })

    }
    handleSubmit = (event) => {
event.preventDefault();

    }
  render() {
   
    return ( <div className="login">    <div className="ro" style={{'margin-top':'100px','margin-left':'100px'}}>
    <div className="card">
                  <form onSubmit={this.handleSubmit}>
            <div className="card-title text-center text-primary"><h1>Login Form</h1></div>
            <div className="card-body">
            <div className="form-group">
            <label>Username:</label><br/>
            <input type="text" name="adminName" placeholder="Username" autocomplete="off" onChange={this.handleChange} className="form-group"/>
            <span className="text-danger">{this.state.formErrorMessage.adminName}</span>
                </div>
                <div className="form-group">
            <label>Password:</label><br/>
            <input type="password" name="adminPassword" placeholder="Password" onChange={this.handleChange}  className="form-group"/>
            <br/><span className="text-danger">{this.state.formErrorMessage.adminPassword}</span>
                </div>
                <button className="btn btn-primary text-center" id="bttn" onClick={() =>this.nextPath("/admin")} disabled={!this.state.formValid.buttonActive}>SIGN IN</button>
                </div>
            </form>
            </div>
    </div></div>

)
};
}
export default withRouter(login);