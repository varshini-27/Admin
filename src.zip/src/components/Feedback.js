import React, { Component } from 'react';

import axios from 'axios';

import "bootstrap/dist/css/bootstrap.min.css";
import './Feedback.css';
const url = "http://localhost:8765/feedbackDetails/feedback/";

class RegisterCustomer extends Component {

    constructor() {
        super();
        this.state = {
            formValue: {
                name: "",
                mailid: "",
                comment:""
            },
            formErrorMessage: {
              name: "",
               mailid: "",
                comment: "",
            },
            formValid: {
                name: false,
                mailid: false,
                comment: false,
                buttonActive: false
            },
            successMessage: "",
            errorMessage: ""
        }

    }

 

    handleChange = (event) => {
        let name = event.target.name;

        let value = event.target.value;

        var { formValue } = this.state;

        this.setState({ formValue: { ...formValue, [name]: value } });

        this.validateField(name, value);

    }
    validateField = (fieldName, value) => {

        let formErrorMessage = this.state.formErrorMessage;

        let formValid = this.state.formValid;

        switch (fieldName) {

            case "name":

                if (value === "") {

                    formErrorMessage.name = "Field Required";

                    formValid.name = false;

                }
                else {

                    formErrorMessage.name = "";

                    formValid.name = true;

                }

                break;

            case "mailid":
                if (value === "") {

                    formErrorMessage.mailid = "Field Required";

                    formValid.mailid = false;

                }
                else {

                    formErrorMessage.mailid = "";

                    formValid.mailid = true;

                }

                break;

            case "comment":
                if (value === "") {

                    formErrorMessage.comment= "Field Required";

                    formValid.comment = false;

                                    }
                      else{                                  
                      formErrorMessage.comment = "";

                    formValid.comment = true;

                }

                break;

                           default: break;

        }
        formValid.buttonActive = formValid.name && formValid.mailid && formValid.comment ;

        this.setState({

            formErrorMessage: formErrorMessage,

            successMessage: "",

            errorMessage: ""

        })
    }
    handleSubmit = (event) => {

        // Prevent page refresh on form submission and invoke registerCustomer method

        event.preventDefault();

        this.submitFeedback();

    }

   submitFeedback = () => {
        axios.post(url, this.state.formValue).then(response => {

            this.setState({ successMessage: response.data });

        }).catch(error => {
            if (error.response)

                this.setState({ errorMessage: error.response.data });

            else

                this.setState({ errorMessage: "Please run the backend" });

        })

    }

    render() {
        return (  
            <div className="card">               <div className="col-lg-3 offset-4" ><br /><br />

                    <div className="card bg-warning">

                        <div className="card-header" style={{"padding-left":"65px"}}>

                            <h4>Feedback Form</h4>

                        </div>

                        <div className="card-body" style={{"padding-left":"30px","text-align":"center"}}>

                            <form onSubmit={this.handleSubmit}>

                                <div className="form-group">

                                    <label>Name</label>

                                    <input type="text" name="name"  className="form-control" onChange={this.handleChange} />

                                    <span name="nameError" className="text-danger">{this.state.formErrorMessage.name}</span>

                                </div>

                                <div className="form-group">

                                    <label >Email Id</label>

                                    <input type="email" name="mailid"  className="form-control" onChange={this.handleChange} />

                                    <span name="emailIdError" className="text-danger">{this.state.formErrorMessage.mailid}</span>

                                </div>

                                <div className="form-group">

                                    <label >Comment</label>

                                    <input type="text" name="comment"  className="form-control" onChange={this.handleChange} />

                                    <span name="passwordError" className="text-danger">{this.state.formErrorMessage.comment}</span>

                                </div>
                                <hr/>
                                <button className="btn btn-primary" >Submit</button>
                            </form>
                            <span name="successMessage" className="text-success">{this.state.successMessage}</span><br/>

                            <span name="errorMessage" className="text-danger">{this.state.errorMessage}</span>
                        </div>
                    </div>
                    </div>
 
                </div>
        );

    }

}

export default RegisterCustomer;




