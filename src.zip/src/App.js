import React from 'react';
import login from './components/login';
import {BrowserRouter as Router,Switch,Route,Redirect} from 'react-router-dom';
import '../node_modules/bootstrap/dist/css/bootstrap.min.css';
import './App.css';
import Admin from './components/Admin';
function App (){
  
    return (<Router>
     
      <Switch>
        <Route exact path="/" render={()=><Redirect to="/login"/>}></Route>
        <Route path="/login" component={login}></Route>
        <Route path="/admin" component={Admin}></Route>
        <Route path="/logout" component={login}></Route>
      </Switch>
    
    </Router>
    );
  }

export default App;
